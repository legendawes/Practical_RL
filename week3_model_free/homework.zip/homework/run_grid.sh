#!/bin/bash
python gridworld.py -a q -k 100 -n 0 -g BookGrid -e 0.5
